let score = 0;
const scoreDisplay = document.getElementById("score");
const bonkButton = document.getElementById("bonkButton");
const bonkDog = document.getElementById("bonkDog");
const bonkSound = document.getElementById("bonkSound");
const leaderboard = document.getElementById("leaderboard");

bonkButton.addEventListener("click", () => {
  score++;
  scoreDisplay.textContent = score;
  bonkDog.classList.add("hit");
  bonkSound.currentTime = 0;
  bonkSound.play();
  setTimeout(() => bonkDog.classList.remove("hit"), 100);
  updateLeaderboard(score);
});

function updateLeaderboard(score) {
  const li = document.createElement("li");
  li.textContent = `You: ${score} BONKS`;
  leaderboard.innerHTML = "";
  leaderboard.appendChild(li);
}

let score = 0;
const scoreElement = document.getElementById("score");
const bonkBtn = document.getElementById("bonk-btn");

const bonkSound = new Audio("bonk.mp3");

bonkBtn.addEventListener("click", () => {
    score++;
    scoreElement.textContent = "Score: " + score;
    bonkSound.currentTime = 0;
    bonkSound.play();
});
